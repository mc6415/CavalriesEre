// This allows for neater code in the app.js file
// module.exports.User = require('./User.js'); -- example line
